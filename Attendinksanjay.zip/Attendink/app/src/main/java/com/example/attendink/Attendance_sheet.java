package com.example.attendink;

public class Attendance_sheet {
    String p1;


    public Attendance_sheet(String p1) {
        this.p1 = p1;
    }

    public String getP1() {
        return p1;
    }

    public void setP1(String p1) {
        this.p1 = p1;
    }

    public Attendance_sheet() {
    }



}
