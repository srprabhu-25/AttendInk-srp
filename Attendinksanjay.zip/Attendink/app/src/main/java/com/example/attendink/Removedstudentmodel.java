package com.example.attendink;

public class Removedstudentmodel {

    private  String abname,absid,absection,abemail,abpassword,abphone,abaddress,abage,abgender;

    public Removedstudentmodel(String abname, String absid, String absection, String abemail, String abpassword, String abphone, String abaddress, String abage, String abgender) {
        this.abname = abname;
        this.absid = absid;
        this.absection = absection;
        this.abemail = abemail;
        this.abpassword = abpassword;
        this.abphone = abphone;
        this.abaddress = abaddress;
        this.abage = abage;
        this.abgender = abgender;
    }

    public String getAbname() {
        return abname;
    }

    public void setAbname(String abname) {
        this.abname = abname;
    }

    public String getAbsid() {
        return absid;
    }

    public void setAbsid(String absid) {
        this.absid = absid;
    }

    public String getAbsection() {
        return absection;
    }

    public void setAbsection(String absection) {
        this.absection = absection;
    }

    public String getAbemail() {
        return abemail;
    }

    public void setAbemail(String abemail) {
        this.abemail = abemail;
    }

    public String getAbpassword() {
        return abpassword;
    }

    public void setAbpassword(String abpassword) {
        this.abpassword = abpassword;
    }

    public String getAbphone() {
        return abphone;
    }

    public void setAbphone(String abphone) {
        this.abphone = abphone;
    }

    public String getAbaddress() {
        return abaddress;
    }

    public void setAbaddress(String abaddress) {
        this.abaddress = abaddress;
    }

    public String getAbage() {
        return abage;
    }

    public void setAbage(String abage) {
        this.abage = abage;
    }

    public String getAbgender() {
        return abgender;
    }

    public void setAbgender(String abgender) {
        this.abgender = abgender;
    }

    public Removedstudentmodel() {
    }
}
