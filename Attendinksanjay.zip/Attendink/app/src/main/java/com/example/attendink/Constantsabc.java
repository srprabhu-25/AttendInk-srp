package com.example.attendink;

public class Constantsabc {

    public static final String[] section={
            "1BCA",
            "2BCA",
            "3BCA",
            "1BCom",
            "2BCom",
            "3BCom",
            "1BSc",
            "2BSc",
            "3BSc"
    };

    public static final String[] section1={
            "All",
            "1BCA",
            "2BCA",
            "3BCA",
            "1BCom",
            "2BCom",
            "3BCom",
            "1BSc",
            "2BSc",
            "3BSc"
    };
}
