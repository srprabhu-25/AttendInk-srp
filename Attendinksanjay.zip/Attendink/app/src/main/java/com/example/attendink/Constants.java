package com.example.attendink;

public class Constants
{
    public static final String[] classes={

            "Science",
            "Commerce",
            "Computer Science",
            "English",
            "Sanskrit",
            "Kannada"


    };

    public static final String[] classes1={
            "All",
            "Science",
            "Commerce",
            "Computer Science",
            "English",
            "Sanskrit",
            "Kannada"

    };
}
